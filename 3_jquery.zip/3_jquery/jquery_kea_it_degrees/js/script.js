$("#aPBA").hover(
  function () {
    $("#PBAMenu").css("display", "block");
  },
  function () {
    $("#PBAMenu").css("display", "none");
  }
);
$("#aAP").hover(
  function () {
    $("#APMenu").css("display", "block");
  },
  function () {
    $("#APMenu").css("display", "none");
  }
);
